package com.email;

import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

@Component
public class MessageReceiver {
	private static final String MESSAGE_QUEUE = "ORDERQUEUE";

	@JmsListener(destination = MESSAGE_QUEUE)
	public void receiveMessage(com.order.OrderVO product) {
		System.out.println("Received " + product);
		if(1==1) {
		throw new RuntimeException();
		}
//		throwexception(product);
	}

//	private void throwexception(Product product) {
//		if (product.getQuantity() % 2 == 0) {
//			throw new RuntimeException();
//		}
//	}
}

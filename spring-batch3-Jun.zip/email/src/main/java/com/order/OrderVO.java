package com.order;

public class OrderVO {
	
	Integer id;
	String item;
	float price;
	Integer quantity;
	public String getItem() {
		return item;
	}
	public void setItem(String item) {
		this.item = item;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "OrderVO [item=" + item + ", price=" + price + ", quantity=" + quantity + "]";
	}
	
	
}

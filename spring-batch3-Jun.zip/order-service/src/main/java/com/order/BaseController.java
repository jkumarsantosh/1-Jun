package com.order;

import java.util.HashMap;
import java.util.Map;

import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;

public class BaseController {

	public BaseController() {
		super();
	}

	@ExceptionHandler(MethodArgumentNotValidException.class)
	Map<String, String> handleException(MethodArgumentNotValidException e) {
		Map<String, String> errorMessages = new HashMap<>();
		e.getAllErrors().forEach(error->{
			String fieldname = ((FieldError)error).getField();
			String msg = ((FieldError)error).getDefaultMessage();
			errorMessages.put(fieldname, msg);
		});
		
		return errorMessages;
	}

}
package com.order;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;
//@EnableEurekaClient
@SpringBootApplication
public class OrderServiceApplication {
	static ConfigurableApplicationContext context;
	public static void main(String[] args) {
		 context  = SpringApplication.run(OrderServiceApplication.class, args);

		// Get JMS template bean reference
//		JmsTemplate jmsTemplate = context.getBean(JmsTemplate.class);
	}
	@Bean
	@LoadBalanced
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}
//	@Bean
//	public JmsTemplate jmsTemplate() {
//		return context.getBean(JmsTemplate.class);
//	}
	
}
